<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>PagePublique</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<link href="css/stylesMontel.css" rel="stylesheet">
<link href="css/responsive.css" rel="stylesheet">
</head>

<body>
	<!-- HEADER -->
	<?php
    require_once('vue\inclusions\selectionHeader.php');
    ?>
	<!-- HEADER -->
	
	<main>
		<?php
		include_once("modele/DAO/photoDAO.class.php");
		include_once("modele\DAO\commentDAO.class.php");
		include_once("modele\DAO\likeDAO.class.php");
		include_once('modele/DAO/friendDAO.class.php');
		$photoDAO = new PhotoDAO();
		$commentDAO = new CommentDAO();
		$likeDAO = new LikeDAO();
		$photoCode = (int) $_GET['photoCode'];
		//Au cas ou la photo n'existe pas dans la base de donnée
		if((!$photoDAO->rechercher_photo($photoCode)) or !(is_int($photoCode))){
			header('location: erreur.php');
		}

		else{
			$auteur = $photoDAO->get_photo_valeur($photoCode, "auteur");
			$liste_commentaire = $commentDAO->afficher_commentaire($photoCode);
			$photoProfilAuteur = $userDAO->get_utilisateur_valeur_avec_username($auteur, "photoProfil");
			$image = $photoDAO->get_photo_valeur($photoCode, "image");
			$nbLike = $photoDAO->get_photo_valeur($photoCode, "like");
		}
		?>
		<section class="main">

			<div class="wrapper">
				
				<div class="post">

					<div class="cadre">
						<div class="info">
							<div class="user">
								<div><img class="profile-pic" src="<?=$photoProfilAuteur?>" alt=""></div>
								<a class="username" href="profilPublique.php?user=<?=$auteur?>"><?=$auteur?></a>
							</div>
						</div>
	
						<img src="<?=$image?>" class="post-image" alt="">
					</div>
					
					<div class="reaction-wrapper">
						<?php
						//Vérifie si la session utilisateur n'est pas null
						if(!empty($nomUtilisateur)){
							//Vérifie si l'utilisateur connecté à déjà like la photo
							if(!$likeDAO->vérification_like($photoCode, $nomUtilisateur)){
								$btnLikeTxt = "Like";
								if(isset($_POST['btnLike'])){
									$nbLikeEnregistre = $likeDAO->nombre_like() + 1;
									$likeDAO->enregistrer_like($nbLikeEnregistre, $photoCode, $nomUtilisateur);
		
									$likeUnePhoto = $likeDAO->nombre_like_photo($photoCode);
									$photoDAO->modifier_like_photo($likeUnePhoto, $photoCode);
									$nbLike = $likeUnePhoto;
									header('location: publiques.php?photoCode=' . $photoCode);
								}
							}
				
							else{
								$btnLikeTxt = "Unlike";
								if(isset($_POST['btnLike'])){
									$likeDAO->supprimer_like($photoCode, $nomUtilisateur);
		
									$unLikeUnePhoto = $likeDAO->nombre_like_photo($photoCode);
									$photoDAO->modifier_like_photo($unLikeUnePhoto, $photoCode);
									$nbLike = $unLikeUnePhoto;
									header('location: publiques.php?photoCode=' . $photoCode);
								}
							}
						}
						else{
							$btnLikeTxt = "Like";
						}

						?>
						<form action="" id="formLike" method="post"></form>
						<button form="formLike" class="like-btn" name="btnLike"><?=$btnLikeTxt?></button>
					</div>

				    <div class="post-content">

						<div class="post-content">
							<p class="likes"><?=$nbLike?> likes</p>
							<!-- Boucle for qui récupère tout les commentaires d'un utilisateur contenus dans la base de donnée -->
							<?php foreach($liste_commentaire as $comment){ ?>
								<?php
									$commentCode = $comment->getId();
									$commentAuteur = $comment->getAuteur();
									$commmentPhotoProfil = $userDAO->get_utilisateur_valeur_avec_username($commentAuteur, "photoProfil");
									$commentMessage = $comment->getMessage();
								?>
								<div class="description">
									<img src="<?=$commmentPhotoProfil;?>" alt="Photo de : <?=$commentAuteur?>">
									<span><a href="profilPublique.php?user=<?=$commentAuteur?>"><?=$commentAuteur?></a></span>
									<br><p><?=$commentMessage?></p>
								</div>
							<?php } ?>
						</div>
					
						<div class="comment-wrapper">
							<?php
							//Envoie un commentaire dans la basse de donnée
							if(isset($_POST["btnEnvoyer"])){
								if(!empty($nomUtilisateur) and !empty($_POST["messageBox"]) and strlen($_POST["messageBox"]) <= 500){
									$idComment = $commentDAO->nombre_commentaire() + 1;
									$idPhotoComment = $photoCode;
									$auteurComment = $nomUtilisateur;
									$auteurPhotoComment = $auteur;
									$messageBox = $_POST["messageBox"];
									$commentDAO->ajouter_commentaire($idComment, $idPhotoComment, $auteurComment, $auteurPhotoComment, $messageBox);
									header('location: publiques.php?photoCode=' . $photoCode);
								}
							}
							?>
							<form action="" id="envoyerMessage" method="POST"></form>
							<textarea form="envoyerMessage" name="messageBox" id="" cols="30" rows="10" class="comment-box" placeholder="Ajouter un commentaire"></textarea>
							<button class="comment-btn" form="envoyerMessage" name="btnEnvoyer">Envoyer!</button>				
						</div>

				    </div>

				</div>

			</div>

		</section>
	</main>

	<footer>
        <p>Olivier Montel Philippe</p>
        <p>Numéro de téléphone: 514-555-555</p>
        <p>Courriel: dfgd@hotmail.com</p>
    </footer>
	<!-- JAVA SCRIPTS -->
    <?php
    include_once('vue/inclusions/jsScript.php');
    ?>
</body>
</html>