<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="css/stylesOlivier.css">
    <link rel="stylesheet" href="css/responsive.css">
    <title>Accueil</title>
</head>
<body>
    <!-- HEADER -->
    <?php
    require_once('vue\inclusions\selectionHeader.php');
    ?>
    <!-- HEADER -->
    <main>
        <?php
            include_once("modele/DAO/photoDAO.class.php");
            $photoDAO = new PhotoDAO();
            $liste_photo = $photoDAO->afficher_photo_publique();
        ?>
        <!-- Boucle for qui récupère tout les photos contenus dans la base de donnée -->
        <!-- Animation diaporama avec Jquerry -->
        <section>
            <h1>Bienvenue</h1>
            <div id="slideshow">
                <?php foreach($liste_photo as $photo){ ?>
                    <figure>
                        <a href="publiques.php?photoCode=<?=$photo->getId();?>"><img src=<?php echo $photo->getImage();?> alt="photo : <?php echo $photo->getAuteur();?>"></a>
                        <figcaption>Auteur: <a href="profilPublique.php?user=<?=$photo->getAuteur();?>"><?php echo $photo->getAuteur();?></a></figcaption>
                    </figure>
                <?php } ?>
            </div>
        </section>

        <section class="aProposDeNous">
            <div>
                <h1>À propos de nous</h1>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ratione, provident consectetur, quia quam atque aut aperiam deleniti accusantium distinctio, facere iste! Est iure labore consectetur cupiditate laborum sunt ducimus doloremque sit laboriosam eveniet! Delectus placeat atque aliquam odio fugit! Dolorum sint accusantium architecto suscipit, aspernatur, adipisci autem, nemo cum nisi excepturi ipsum molestiae. Itaque rerum ad deserunt officia dolor corporis aut, quos autem ipsam necessitatibus aperiam porro cum! Quasi error labore sunt explicabo quam voluptatem aspernatur! Suscipit corrupti, delectus exercitationem facere nobis rem magnam consequuntur dolorem fugiat, aspernatur vitae culpa consequatur veritatis. Voluptatibus nulla repudiandae consectetur officia a maxime dolorum.</p>
                <p>Officia aliquam ipsam laudantium distinctio eligendi aperiam nisi, sequi voluptates facilis animi consequatur molestiae. Quasi aliquam non nam voluptates voluptas velit, omnis dolore quam voluptatum quia temporibus officiis rerum nihil natus veniam deleniti numquam facilis, distinctio nobis. Ipsa eaque sapiente debitis optio reiciendis deleniti magnam, exercitationem recusandae maiores ipsum? Nobis hic saepe porro esse suscipit! Sit ullam asperiores eius accusantium ut similique? Temporibus sed ratione eum deserunt enim optio laboriosam asperiores eius aliquid assumenda libero exercitationem voluptatibus earum, autem totam rem sit doloribus ipsa voluptatum fugiat quasi. Sint, labore ipsam. Minima sed quaerat dignissimos voluptatibus hic laborum tenetur libero explicabo!</p>
                <p>Quae magnam nihil qui id labore? Distinctio illum magnam odio minima voluptates adipisci, tempore nihil hic explicabo eum fugit ratione ab deserunt enim error pariatur, perferendis numquam saepe, culpa doloremque. Error optio minima dolorum omnis exercitationem beatae at obcaecati. Necessitatibus odit vel quibusdam impedit recusandae distinctio quam error alias ullam, expedita explicabo dolores amet velit! Saepe quisquam nihil iste dicta reiciendis libero est pariatur! Itaque possimus nemo velit veritatis, eum corporis aperiam inventore eveniet, nobis debitis culpa asperiores doloremque facilis quisquam odio, cum alias? Voluptas, deserunt incidunt! Quasi odio autem atque odit beatae minus, voluptatem nemo quisquam minima fugit! Ea.</p>
                <p>Aperiam architecto deserunt natus exercitationem adipisci, velit debitis excepturi similique iusto modi itaque dolor explicabo officia vel aliquam placeat fugit ab! Veniam asperiores accusantium dolore provident excepturi et vel quisquam sunt dolores harum placeat quos illum nisi necessitatibus veritatis quia perspiciatis autem sequi alias esse, tempora itaque facere eaque quae. Ex totam sapiente unde, nulla tempore soluta magni labore recusandae nobis fuga pariatur exercitationem quis quia dolorum facilis doloremque voluptatibus magnam quos consequuntur repellendus repellat. Quasi blanditiis harum autem in ipsam voluptatem libero reprehenderit molestiae ad, aspernatur quo culpa dolores cumque saepe aperiam deserunt. Commodi ipsam vel repellat at fuga!</p>
                <p>Et quidem facilis nemo quia vero sunt repellat quibusdam, velit ab accusantium perferendis omnis, autem dignissimos fugit ratione! Minima totam doloremque suscipit libero adipisci officia dolore! Deserunt corrupti consectetur quasi. Voluptas sequi repudiandae natus exercitationem cum in minus enim labore libero! Est, excepturi harum veniam laborum vel dolores esse molestias ipsum reiciendis dolor nisi voluptatibus perferendis aliquam porro perspiciatis cupiditate nostrum nobis ut quos accusantium ex reprehenderit aliquid iste. Ut nesciunt inventore qui fuga praesentium commodi quasi, minus unde, temporibus, suscipit quo possimus enim recusandae ducimus error provident vero eos voluptatum id veritatis explicabo itaque esse facere! Minus, quas officiis!</p>
            </div>
        </section>
    </main>

    <footer>
        <p>Olivier Montel Philippe</p>
        <p>Numéro de téléphone: 514-555-555</p>
        <p>Courriel: dfgd@hotmail.com</p>
    </footer>
    <!-- JAVA SCRIPTS -->
    <?php
    include_once('vue/inclusions/jsScript.php');
    ?>
</body>
</html>