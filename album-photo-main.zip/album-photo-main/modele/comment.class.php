<?php
class Comment{
    private $id;
    private $idPhoto;
    private $auteur;
    private $auteurPhoto;
    private $message;

    public function __construct($id, $idPhoto, $auteur, $auteurPhoto, $message)
    {
        $this->id = $id;
        $this->idPhoto = $idPhoto;
        $this->auteur = $auteur;
        $this->auteurPhoto = $auteurPhoto;
        $this->message = $message;
    }

    public function getId(){
        return $this->id;
    }

    public function getIdPhoto(){
        return $this->idPhoto;
    }

    public function getAuteur(){
        return $this->auteur;
    }

    public function getAuteurPhoto(){
        return $this->auteurPhoto;
    }

    public function getMessage(){
        return $this->message;
    }

    public function __toString()
    {
        return "$this->id, $this->idPhoto, $this->auteur, $this->auteurPhoto, $this->message";
    }
}
?>