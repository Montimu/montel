<?php
class Like{
    private $id;
    private $idPhotoLike;
    private $likeAuteur;

    public function __construct($id, $idPhotoLike, $likeAuteur)
    {
        $this->id = $id;
        $this->idPhotoLike = $idPhotoLike;
        $this->likeAuteur = $likeAuteur;
    }

    public function getId(){
        return $this->id;
    }

    public function getIdPhotoLike(){
        return $this->idPhotoLike;
    }

    public function getLikeAuteur(){
        return $this->likeAuteur;
    }

    public function __toString()
    {
        return "$this->id, $this->idPhotoLike, $this->likeAuteur";
    }
}
?>