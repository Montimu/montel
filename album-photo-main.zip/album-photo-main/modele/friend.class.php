<?php
class Friend{
    private $id;
    private $transmetteur;
    private $receveur;

    public function __construct($id, $transmetteur, $receveur)
    {
        $this->id = $id;
        $this->transmetteur = $transmetteur;
        $this->receveur = $receveur;
    }

    public function getId(){
        return $this->id;
    }

    public function getTransmetteur(){
        return $this->transmetteur;
    }

    public function getReceveur(){
        return $this->receveur;
    }

    public function __toString()
    {
        return "$this->id, $this->transmetteur, $this->receveur";
    }
}
?>