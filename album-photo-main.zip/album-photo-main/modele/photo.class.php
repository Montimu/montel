<?php

class Photo{
    private $id;
    private $auteur;
    private $image;
    private $nbLike;
    private $statut;

    public function __construct($id, $auteur, $image, $nbLike, $statut)
    {
        $this->id = $id;
        $this->auteur = $auteur;
        $this->image = $image;
        $this->nbLike = $nbLike;
        $this->statut = $statut;
    }

    public function getId(){
        return $this->id;
    }

    public function getAuteur(){
        return $this->auteur;
    }
    public function getImage(){
        return$this->image;
    }
    public function getNbLike(){
        return $this->nbLike;
    }
    public function setNbLike($newNbLike){
        return $this->nbLike = $newNbLike;
    }
    public function getStatut(){
        return $this->statut;
    }

    public function __toString()
    {
        return "$this->id, $this->auteur, $this->image, $this->nbLike, $this->statut";
    }

}