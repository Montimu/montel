<?php	
	interface ConfigBD
	{	
		const BD_HOTE = "localhost";
		const BD_UTILISATEUR = "root";
		const BD_MOT_PASSE = "root";
		const BD_NOM = "album";
	}