<?php
include_once('connexionBD.class.php'); 
include_once('modele/comment.class.php');

class CommentDAO{

    //Afficher les commentaire liés à une photo
    public static function afficher_commentaire($code_photo){
        $liste_commentaire = array();
        try {

            $requete = "SELECT * FROM comment WHERE code_photo = '$code_photo'";
			$db = ConnexionBD::getInstance();
            $res = $db->query($requete);
             
            foreach($res as $row) {
                $comment = new Comment($row['code'], $row['code_photo'], $row['auteur'], $row['auteur_photo'], $row['message']);
                array_push($liste_commentaire, $comment);
            }
            return $liste_commentaire;
            $res->closeCursor();
            ConnexionBD::close();

        } catch (PDOException $e) {
            print "Error!: " . $e->getMessage() . "<br/>";

        }
    }

    //Ajouter un commentaire
    public static function ajouter_commentaire($id, $idPhoto, $auteur, $auteurPhoto, $message){
        try
		{
			$db = ConnexionBD::getInstance();
            
			$requete = "INSERT INTO comment (code, code_photo, auteur, auteur_photo, message)
            VALUES ('".$id."','".$idPhoto."','".$auteur."','".$auteurPhoto."','".$message."')";
            $db->exec($requete);
            ConnexionBD::close();
		}
		catch(PDOException $e)
		{
			throw $e;
		}
    }

    //Modifier le nom de l'auteur du commentaire
    public static function modifier_auteur_comment($nomUtilisateur, $nouveauNom){
        try
		{
			$db = ConnexionBD::getInstance();

            $requete = "UPDATE comment SET auteur = '$nouveauNom' WHERE auteur = '$nomUtilisateur'";
            $db->exec($requete);
            ConnexionBD::close();
		}
		catch(PDOException $e)
		{
			throw $e;
		}
    }

    //Supprimer les commentaires appartenent à une photo
    public static function supprimer_commentaire_photo($photoCode){
        try
		{
			$db = ConnexionBD::getInstance();
            
			$requete = "DELETE FROM comment WHERE code_photo = $photoCode";
            $db->exec($requete);
            ConnexionBD::close();
		}
		catch(PDOException $e)
		{
			throw $e;
		}
    }

    //Récupérer le nombre de commentaire contenu dans la base de donnée
    public static function nombre_commentaire(){
        try
		{
			$db = ConnexionBD::getInstance();

            $requete = "SELECT MAX(code) as count_comment FROM comment";
            $db = ConnexionBD::getInstance();
            $resultat = $db->query($requete);
            
            foreach($resultat as $row) {
                return $row['count_comment'];
            }

            ConnexionBD::close();
		}
		catch(PDOException $e)
		{
			throw $e;
		}
    }
}
?>