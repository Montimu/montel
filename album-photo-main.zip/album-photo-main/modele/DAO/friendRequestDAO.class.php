<?php
include_once('connexionBD.class.php'); 
include_once('modele/friendRequest.class.php');

class FriendRequestDAO{
    //Afficher tous les demandes d'amis d'un utilisateur
    public static function afficher_demande_ami($nomUtilisateur){
        $liste_demande_ami = array();
        try {

            $requete = "SELECT * FROM friendrequest WHERE requester = '$nomUtilisateur'";
			$db = ConnexionBD::getInstance();
            $res = $db->query($requete);
             
            foreach($res as $row) {
                $demande = new FriendRequest($row['code'], $row['transmitter'], $row['requester']);
                array_push($liste_demande_ami, $demande);
            }
            return $liste_demande_ami;
            $res->closeCursor();
            ConnexionBD::close();

        } catch (PDOException $e) {
            print "Error!: " . $e->getMessage() . "<br/>";

        }
    }

    //Créer une demande d'ami
    public static function creer_une_demande_ami($id, $transmetteur, $receveur){
        try
		{
			$db = ConnexionBD::getInstance();
            
			$requete = "INSERT INTO friendrequest (code, transmitter, requester)
            VALUES ('".$id."','".$transmetteur."','".$receveur."')";
            $db->exec($requete);
            ConnexionBD::close();
		}
		catch(PDOException $e)
		{
			throw $e;
		}
    }

    //Modifier le nom de l'auteur du commentaire
    public static function modifier_auteur_friend_request($nomUtilisateur, $nouveauNom){
        try
		{
			$db = ConnexionBD::getInstance();

            $requeteTransmitter = "UPDATE friend SET transmitter = '$nouveauNom' WHERE transmitter = '$nomUtilisateur'";
            $requeteRequester = "UPDATE friend SET requester = '$nouveauNom' WHERE requester = '$nomUtilisateur'";

            $db->exec($requeteTransmitter);
            $db->exec($requeteRequester);
            ConnexionBD::close();
		}
		catch(PDOException $e)
		{
			throw $e;
		}
    }

    
    //Supprimer une demande d'Ami
    public static function supprimer_demande($transmetteur, $receveur){
        try
		{
			$db = ConnexionBD::getInstance();
            
			$requete = "DELETE FROM friendrequest WHERE transmitter = '$transmetteur' AND requester = '$receveur'";
            $db->exec($requete);
            ConnexionBD::close();
		}
		catch(PDOException $e)
		{
			throw $e;
		}
    }

     //Rechercher une demande d'ami dans la base de données pour savoir s'il existe.
     public static function rechercher_demande_ami($transmetteur, $receveur){
        try
		{
            
            $requete = "SELECT * FROM friendrequest WHERE transmitter = '$transmetteur' AND requester = '$receveur'";
			$db = ConnexionBD::getInstance();
            $res = $db->query($requete);

            foreach($res as $row){
                if($row['transmitter'] == $transmetteur and $row['requester'] = $receveur){
                    return true;
                }

                else{
                    return false;
                }
            }

            $res->closeCursor();

            ConnexionBD::close();
		}
		catch(PDOException $e)
		{
			throw $e;
		}
    }


    //Récupérer le nombre de demandes d'amis contenu dans la base de donnée
    public static function nombre_demande_amis(){
        try
		{
			$db = ConnexionBD::getInstance();

            $requete = "SELECT MAX(code) AS count_demande_amis FROM friendrequest";
            $db = ConnexionBD::getInstance();
            $resultat = $db->query($requete);
            
            foreach($resultat as $row) {
                return $row['count_demande_amis'];
            }

            ConnexionBD::close();
		}
		catch(PDOException $e)
		{
			throw $e;
		}
    }
}
?>