<?php
include_once('connexionBD.class.php'); 
include_once('modele/photo.class.php');

class PhotoDAO{

    //Afficher tous les photos publiques dans le catalog
    public static function afficher_photo_publique(){
        $liste_photo = array();
        try {

            $requete = "SELECT * FROM photo WHERE statut = 'public'";
			$db = ConnexionBD::getInstance();
            $res = $db->query($requete);
             
            foreach($res as $row) {
                $photo = new Photo($row['code'], $row['autor'], $row['image'], $row['nbLike'], $row['statut']);
                array_push($liste_photo, $photo);
            }
            return $liste_photo;
            $res->closeCursor();
            ConnexionBD::close();

        } catch (PDOException $e) {
            print "Error!: " . $e->getMessage() . "<br/>";

        }
    }

    //Créer une photo
    public static function creer_photo($id, $auteur, $image, $nbLike, $statut){
        try
		{
			$db = ConnexionBD::getInstance();
            
			$requete = "INSERT INTO photo (code, autor, image, nbLike, statut)
            VALUES ('".$id."','".$auteur."','".$image."','".$nbLike."','".$statut."')";
            $db->exec($requete);
            ConnexionBD::close();
		}
		catch(PDOException $e)
		{
			throw $e;
		}
    }

    //Récuperer les photos d'un utilisateur
    public static function get_photo_utilisateur($nomUtilisateur, $statut){
        $liste_photo = array();
        try {

            switch($statut){
                case 'public': 
                    $requete = "SELECT * FROM photo WHERE autor = '$nomUtilisateur' AND statut = 'public'";
                break;
                case 'protected':
                    $requete = "SELECT * FROM photo WHERE autor = '$nomUtilisateur' AND statut != 'private'";
                break;
                default:
                    $requete = "SELECT * FROM photo WHERE autor = '$nomUtilisateur'";
            }
            
			$db = ConnexionBD::getInstance();
            $res = $db->query($requete);
             
            foreach($res as $row) {
                $photo = new Photo($row['code'], $row['autor'], $row['image'], $row['nbLike'], $row['statut']);
                array_push($liste_photo, $photo);
            }
            return $liste_photo;
            $res->closeCursor();
            ConnexionBD::close();

        } catch (PDOException $e) {
            print "Error!: " . $e->getMessage() . "<br/>";

        }
    }

    //Récupérer les attributs d'une photo avec un code
    public static function get_photo_valeur($code, $value){
        try
        {
            $requete = "SELECT * FROM photo WHERE code = $code";
            $db = ConnexionBD::getInstance();
            $res = $db->query($requete);
    
            foreach($res as $row) {
                $photo = new Photo($row['code'], $row['autor'], $row['image'], $row['nbLike'], $row['statut']);
            }
            $res->closeCursor();
            ConnexionBD::close();
    
            switch($value){
                case 'code': 
                    return $photo->getId();
                break;
                case 'auteur':
                    return $photo->getAuteur();
                break;
                case 'image':
                    return $photo->getImage();
                break;
                case 'like':
                    return $photo->getNbLike();
                break;
                case 'statut':
                    return $photo->getStatut();
                break;
            }
        }
        catch(PDOException $e)
        {
            throw $e;
        }
    }

    //Modifier le statut de la photo
    public static function modifier_photo_statut($code, $statut){
        try
		{
			$db = ConnexionBD::getInstance();

            $requete = "UPDATE photo SET statut = '$statut' WHERE code = $code";
            $db->exec($requete);
            ConnexionBD::close();
		}
		catch(PDOException $e)
		{
			throw $e;
		}
    }

    //Modifier le nom de l'auteur de la photo
    public static function modifier_auteur_photo($nomUtilisateur, $nouveauNom){
        try
		{
			$db = ConnexionBD::getInstance();

            $requete = "UPDATE photo SET autor = '$nouveauNom' WHERE autor = '$nomUtilisateur'";
            $db->exec($requete);
            ConnexionBD::close();
		}
		catch(PDOException $e)
		{
			throw $e;
		}
    }

    //Like une photo
    public static function modifier_like_photo($valeur, $code){
        try
		{
			$db = ConnexionBD::getInstance();

            $requete = "UPDATE photo SET nbLike = '$valeur' WHERE code = $code";
            $db->exec($requete);
            ConnexionBD::close();
		}
		catch(PDOException $e)
		{
			throw $e;
		}
    }

    //Supprimer une photo
    public static function supprimer_photo($code){
        try
		{
			$db = ConnexionBD::getInstance();
            
			$requete = "DELETE FROM photo WHERE code = $code";
            $db->exec($requete);
            ConnexionBD::close();
		}
		catch(PDOException $e)
		{
			throw $e;
		}
    }

    //Rechercher une photo dans la base de données pour savoir s'il existe.
    public static function rechercher_photo($photoCode){
        try
		{
            $requete = "SELECT * FROM photo WHERE code = $photoCode";
			$db = ConnexionBD::getInstance();
            $res = $db->query($requete);

            foreach($res as $row){
                if($row['code'] == $photoCode){
                    return true;
                }

                else{
                    return false;
                }
            }

            $res->closeCursor();

            ConnexionBD::close();
		}
		catch(PDOException $e)
		{
			throw $e;
		}
    }

    //Récupérer le nombre de photo contenu dans la base de donnée
    public static function nombre_photo(){
        try
		{
			$db = ConnexionBD::getInstance();

            $requete = "SELECT MAX(code) AS count_photo FROM photo";
            $db = ConnexionBD::getInstance();
            $resultat = $db->query($requete);
            
            foreach($resultat as $row) {
                return $row['count_photo'];
            }

            ConnexionBD::close();
		}
		catch(PDOException $e)
		{
			throw $e;
		}
    }
}


?>