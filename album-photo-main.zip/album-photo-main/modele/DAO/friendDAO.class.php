<?php
include_once('connexionBD.class.php'); 
include_once('modele/friend.class.php');

class FriendDAO{
    //Afficher tous les amis d'un utilisateur
    public static function afficher_amis($nomUtilisateur){
        $liste_demande_ami = array();
        try {

            $requete = "SELECT * FROM friend WHERE transmitter = '$nomUtilisateur' OR requester = '$nomUtilisateur'";
			$db = ConnexionBD::getInstance();
            $res = $db->query($requete);
             
            foreach($res as $row) {
                $demande = new Friend($row['code'], $row['transmitter'], $row['requester']);
                array_push($liste_demande_ami, $demande);
            }
            return $liste_demande_ami;
            $res->closeCursor();
            ConnexionBD::close();

        } catch (PDOException $e) {
            print "Error!: " . $e->getMessage() . "<br/>";

        }
    }

    //Créer un ami
    public static function creer_un_ami($id, $transmetteur, $receveur){
        try
		{
			$db = ConnexionBD::getInstance();
            
			$requete = "INSERT INTO friend (code, transmitter, requester)
            VALUES ('".$id."','".$transmetteur."','".$receveur."')";
            $db->exec($requete);
            ConnexionBD::close();
		}
		catch(PDOException $e)
		{
			throw $e;
		}
    }

    //Modifier le nom de l'auteur du commentaire
    public static function modifier_auteur_friend($nomUtilisateur, $nouveauNom){
        try
		{
			$db = ConnexionBD::getInstance();

            $requeteTransmitter = "UPDATE friend SET transmitter = '$nouveauNom' WHERE transmitter = '$nomUtilisateur'";
            $requeteRequester = "UPDATE friend SET requester = '$nouveauNom' WHERE requester = '$nomUtilisateur'";

            $db->exec($requeteTransmitter);
            $db->exec($requeteRequester);
            ConnexionBD::close();
		}
		catch(PDOException $e)
		{
			throw $e;
		}
    }

    //Supprimer un ami
    public static function supprimer_ami($transmetteur, $receveur, $request){
        try
		{
			$db = ConnexionBD::getInstance();
            
            switch($request){
                case 'transmetteur': 
                    $requete = "DELETE FROM friend WHERE transmitter = '$transmetteur' AND requester = '$receveur'";                
                    break;
                case 'receveur':
                    $requete = "DELETE FROM friend WHERE transmitter = '$receveur' AND requester = '$transmetteur'";
                    break;
            }
            $db->exec($requete);
            ConnexionBD::close();
		}
		catch(PDOException $e)
		{
			throw $e;
		}
    }

    //Vérifier si l'utilisateur est déjà l'ami d'un autre utilisateur.
    public static function rechercher_ami($transmetteur, $receveur, $request){
        try
		{
            switch($request){
                case 'transmetteur': 
                    $requete = "SELECT * FROM friend WHERE transmitter = '$transmetteur' AND requester = '$receveur'";
                break;
                case 'receveur':
                    $requete = "SELECT * FROM friend WHERE transmitter = '$receveur' AND requester = '$transmetteur'";
                break;
            }

			$db = ConnexionBD::getInstance();
            $res = $db->query($requete);

            foreach($res as $row){
                if($row['transmitter'] == $transmetteur and $row['requester'] = $receveur){
                    return true;
                }

                elseif($row['transmitter'] == $receveur and $row['requester'] = $transmetteur){
                    return true;
                }

                else{
                    return false;
                }
            }

            $res->closeCursor();

            ConnexionBD::close();
		}
		catch(PDOException $e)
		{
			throw $e;
		}
    }


    //Récupérer le nombre d'amis contenu dans la base de donnée
    public static function nombre_amis(){
        try
		{
			$db = ConnexionBD::getInstance();

            $requete = "SELECT MAX(code) AS count_amis FROM friend";
            $db = ConnexionBD::getInstance();
            $resultat = $db->query($requete);
            
            foreach($resultat as $row) {
                return $row['count_amis'];
            }

            ConnexionBD::close();
		}
		catch(PDOException $e)
		{
			throw $e;
		}
    }

    //Vérifier si l'utilisateur est déjà l'ami d'un autre utilisateur.
    public static function test_ami($transmetteur, $receveur, $request){
        
        switch($request){
            case 'transmetteur': 
                $requete = "SELECT * FROM friend WHERE transmitter = '$transmetteur' AND requester = '$receveur'";
            break;
            case 'receveur':
                $requete = "SELECT * FROM friend WHERE transmitter = '$receveur' AND requester = '$transmetteur'";
            break;
        }

        return $requete;

    }
}
?>