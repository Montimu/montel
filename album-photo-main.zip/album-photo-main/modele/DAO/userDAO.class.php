<?php
include_once('connexionBD.class.php'); 
include_once('modele/user.class.php');

class UserDAO{

    //Créer un utilisateur
    public static function creer_utilisateur($code, $prenom, $nom, $nomUtilisateur, $motDePasse, 
    $email, $telephone, $photoProfil){
        try
		{
			$db = ConnexionBD::getInstance();
            
			$requete = "INSERT INTO user (code, firstname, lastname, username, password, 
            email, telephone, profile_picture)
            VALUES ('".$code."','".$prenom."','".$nom."','".$nomUtilisateur."','".$motDePasse."','".$email."','".$telephone."','".$photoProfil."')";
            $db->exec($requete);
            ConnexionBD::close();
		}
		catch(PDOException $e)
		{
			throw $e;
		}
    }

    //Supprimer un utilisateur
    public static function supprimer_utilisateur($code){
        try
		{
			$db = ConnexionBD::getInstance();
            
			$requete = "DELETE FROM user WHERE code = $code";
            $db->exec($requete);
            ConnexionBD::close();
		}
		catch(PDOException $e)
		{
			throw $e;
		}
    }

    //Modifier les informations d'un utilisateurs
    public static function modifier_utilisateur($code, $prenom, $nom, 
    $nomUtilisateur, $motDePasse, $email, $telephone){
        try
		{
			$db = ConnexionBD::getInstance();

            $requete = "UPDATE user SET firstname = '".$prenom."', lastname = '".$nom."', username = '".$nomUtilisateur."', password = '".$motDePasse."', email = '".$email."', telephone = '".$telephone."' WHERE code =".$code;
            $db->exec($requete);
            ConnexionBD::close();
		}
		catch(PDOException $e)
		{
			throw $e;
		}
    }

    //Modifier la photo de profil de l'utilisateur
    public static function modifier_photo_profil($valeur, $nomUtilisateur){
        try
		{
			$db = ConnexionBD::getInstance();

            $requete = "UPDATE user SET profile_picture = '$valeur' WHERE username = '$nomUtilisateur'";
            $db->exec($requete);
            ConnexionBD::close();
		}
		catch(PDOException $e)
		{
			throw $e;
		}
    }

    //Récupérer le nombre d'utilisateur contenu dans la base de donnée
    public static function nombre_utilisateur(){
        try
		{
			$db = ConnexionBD::getInstance();

            $requete = "SELECT MAX(code) AS count_user FROM user";
            $db = ConnexionBD::getInstance();
            $resultat = $db->query($requete);
            
            foreach($resultat as $row) {
                return $row['count_user'];
            }

            ConnexionBD::close();
		}
		catch(PDOException $e)
		{
			throw $e;
		}
    }

    //Afficher une liste d'utilisateur
    public static function afficher_utilisateur(){
        $liste_user = array();
        try {

            $requete = 'SELECT * FROM user WHERE firstname != "admin"';
			$db = ConnexionBD::getInstance();
            $res = $db->query($requete);
             
            foreach($res as $row) {
                $user = new User($row["code"], $row["firstname"], $row["lastname"], 
                $row["username"], $row["password"], $row["email"], 
                $row["telephone"], $row["profile_picture"]);
                array_push($liste_user, $user);
            }
            return $liste_user;
            $res->closeCursor();
            ConnexionBD::close();

        } catch (PDOException $e) {
            print "Error!: " . $e->getMessage() . "<br/>";

        }
    }

    //Récupérer les attributs de l'utilsateurs avec un code
    public static function get_utilisateur_valeur($code, $value){
        try
		{
            $requete = "SELECT * FROM user WHERE code = $code";
			$db = ConnexionBD::getInstance();
            $res = $db->query($requete);

            foreach($res as $row) {
                $user = new User($row["code"], $row["firstname"], $row["lastname"], 
                $row["username"], $row["password"], $row["email"], 
                $row["telephone"], $row["profile_picture"]);
            }
            $res->closeCursor();
            ConnexionBD::close();

			switch($value){
                case 'prenom': 
                    return $user->getPrenom();
                break;
                case 'nom':
                    return $user->getNom();
                break;
                case 'nomUtilisateur':
                    return $user->getNomUtilisateur();
                break;
                case 'motDePasse':
                    return $user->getMotDePasse();
                break;
                case 'email':
                    return $user->getEmail();
                break;
                case 'telephone':
                    return $user->getTelephone();
                break;
            }
		}
		catch(PDOException $e)
		{
			throw $e;
		}
    }

    //Récupérer les attributs de l'utilsateurs avec un nom d'utilisateur
    public static function get_utilisateur_valeur_avec_username($nomUtilisateur, $value){
        try
		{
            $requete = "SELECT * FROM user WHERE username = '$nomUtilisateur'";
			$db = ConnexionBD::getInstance();
            $res = $db->query($requete);

            foreach($res as $row) {
                $user = new User($row["code"], $row["firstname"], $row["lastname"], 
                $row["username"], $row["password"], $row["email"], 
                $row["telephone"], $row["profile_picture"]);
            }
            $res->closeCursor();
            ConnexionBD::close();

			switch($value){
                case 'code': 
                    return $user->getId();
                break;
                case 'prenom': 
                    return $user->getPrenom();
                break;
                case 'nom':
                    return $user->getNom();
                break;
                case 'nomUtilisateur':
                    return $user->getNomUtilisateur();
                break;
                case 'motDePasse':
                    return $user->getMotDePasse();
                break;
                case 'email':
                    return $user->getEmail();
                break;
                case 'telephone':
                    return $user->getTelephone();
                break;
                case 'photoProfil': 
                    return $user->getPhotoProfil();
                break;
            }
		}
		catch(PDOException $e)
		{
			throw $e;
		}
    }

    //Rechercher un utilisateur dans la base de données pour savoir s'il existe.
    public static function rechercher_utilisateur($nomUtilisateur, $motDePasse){
        try
		{
            
            $requete = "SELECT * FROM user WHERE username = '$nomUtilisateur' AND password = '$motDePasse'";
			$db = ConnexionBD::getInstance();
            $res = $db->query($requete);

            foreach($res as $row){
                if($row['username'] == $nomUtilisateur and $row['password'] == $motDePasse){
                    return true;
                }

                else{
                    return false;
                }
            }

            $res->closeCursor();

            ConnexionBD::close();
		}
		catch(PDOException $e)
		{
			throw $e;
		}
    }

    //Rechercher un utilisateur dans la base de données pour savoir s'il existe.
    public static function trouver_utilisateur($nomUtilisateur){
        try
		{
            
            $requete = "SELECT * FROM user WHERE username = '$nomUtilisateur'";
			$db = ConnexionBD::getInstance();
            $res = $db->query($requete);

            foreach($res as $row){
                if($row['username'] == $nomUtilisateur){
                    return true;
                }

                else{
                    return false;
                }
            }

            $res->closeCursor();

            ConnexionBD::close();
		}
		catch(PDOException $e)
		{
			throw $e;
		}
    }

    //Afficher les utilisateurs dans la page rechercher un utilisateur
    public static function afficher_recherche_utilisateur($nomUtilisateur){
        $liste_user = array();
        try {

            $requete = "SELECT * FROM user WHERE username LIKE '%$nomUtilisateur%'";
			$db = ConnexionBD::getInstance();
            $res = $db->query($requete);
             
            foreach($res as $row) {
                $user = new User($row["code"], $row["firstname"], $row["lastname"], 
                $row["username"], $row["password"], $row["email"], 
                $row["telephone"], $row["profile_picture"]);
                array_push($liste_user, $user);
            }

            return $liste_user;
            $res->closeCursor();
            ConnexionBD::close();

        } catch (PDOException $e) {
            print "Error!: " . $e->getMessage() . "<br/>";

        }
    }

    //Rechercher un utilisateur dans la base de données pour savoir s'il existe.
    public static function vérification_nom_utilisateur($nomUtilisateur){
        try
		{
            
            $requete = "SELECT * FROM user WHERE username = '$nomUtilisateur'";
			$db = ConnexionBD::getInstance();
            $res = $db->query($requete);

            foreach($res as $row){
                if($row['username'] == $nomUtilisateur){
                    return true;
                }

                else{
                    return false;
                }
            }

            $res->closeCursor();

            ConnexionBD::close();
		}
		catch(PDOException $e)
		{
			throw $e;
		}
    }

    //Tester des functions
    public static function test_utilisateur(){
        try
		{
			$db = ConnexionBD::getInstance();
           
            $requete = "INSERT INTO user (code ,firstname ,lastname, username, password, 
            email, telephone, profile_picture)
            VALUES (555, 'dsfsf', 'dsfsf', 'dsfsf', 'dsfsf', 'dsfsf', 'dsfsf', 'dsfsf', 'dsfsf')";

            $db->exec($requete);
            ConnexionBD::close();
		}
		catch(PDOException $e)
		{
			throw $e;
		}
    }
}
?>
