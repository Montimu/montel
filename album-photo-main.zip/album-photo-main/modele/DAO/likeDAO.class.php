<?php
include_once('connexionBD.class.php'); 
include_once('modele/like.class.php');

class LikeDAO{
    //Enregistrer un like
    public static function enregistrer_like($id, $idPhotoLike, $likeAuteur){
        try
		{
			$db = ConnexionBD::getInstance();
            
			$requete = "INSERT INTO like_table (code, code_photo_like, like_auteur)
            VALUES ('".$id."','".$idPhotoLike."','".$likeAuteur."')";
            $db->exec($requete);
            ConnexionBD::close();
		}
		catch(PDOException $e)
		{
			throw $e;
		}
    }

    //Modifier le nom de l'auteur de like
    public static function modifier_auteur_like($nomUtilisateur, $nouveauNom){
        try
		{
			$db = ConnexionBD::getInstance();

            $requete = "UPDATE like_table SET like_auteur = '$nouveauNom' WHERE like_auteur = '$nomUtilisateur'";
            $db->exec($requete);
            ConnexionBD::close();
		}
		catch(PDOException $e)
		{
			throw $e;
		}
    }

    //Supprimer un like
    public static function supprimer_like($idPhotoLike, $likeAuteur){
        try
		{
			$db = ConnexionBD::getInstance();
            
			$requete = "DELETE FROM like_table WHERE code_photo_like = $idPhotoLike AND like_auteur = '$likeAuteur'";
            $db->exec($requete);
            ConnexionBD::close();
		}
		catch(PDOException $e)
		{
			throw $e;
		}
    }

    //Supprimer les likes appartenent à une photo
    public static function supprimer_like_photo($photoCode){
        try
		{
			$db = ConnexionBD::getInstance();
            
			$requete = "DELETE FROM like_table WHERE code_photo_like = $photoCode";
            $db->exec($requete);
            ConnexionBD::close();
		}
		catch(PDOException $e)
		{
			throw $e;
		}
    }

    //Vérifier si l'utilisateur à like une photo.
    public static function vérification_like($idPhotoLike, $likeAuteur){
        try
		{
            
            $requete = "SELECT * FROM like_table WHERE code_photo_like = $idPhotoLike AND like_auteur = '$likeAuteur'";
			$db = ConnexionBD::getInstance();
            $res = $db->query($requete);

            foreach($res as $row){
                if($row['code_photo_like'] == $idPhotoLike  and $row['like_auteur'] == $likeAuteur){
                    return true;
                }

                else{
                    return false;
                }
            }

            $res->closeCursor();

            ConnexionBD::close();
		}
		catch(PDOException $e)
		{
			throw $e;
		}
    }

    //Récupérer le nombre de like contenu dans la base de donnée
    public static function nombre_like(){
        try
		{
			$db = ConnexionBD::getInstance();

            $requete = "SELECT COUNT(*) as count_like FROM like_table";
            $db = ConnexionBD::getInstance();
            $resultat = $db->query($requete);
            
            foreach($resultat as $row) {
                return $row['count_like'];
            }

            ConnexionBD::close();
		}
		catch(PDOException $e)
		{
			throw $e;
		}
    }

    //Récupérer le nombre de like d'une photo sélectionnée
    public static function nombre_like_photo($idPhotoLike){
        try
		{
			$db = ConnexionBD::getInstance();

            $requete = "SELECT COUNT(*) as count_like FROM like_table WHERE code_photo_like = $idPhotoLike";
            $db = ConnexionBD::getInstance();
            $resultat = $db->query($requete);
            
            foreach($resultat as $row) {
                return $row['count_like'];
            }

            ConnexionBD::close();
		}
		catch(PDOException $e)
		{
			throw $e;
		}
    }
}
?>