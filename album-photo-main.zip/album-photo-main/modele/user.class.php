<?php

class User {
    private  $id;
    private  $premon;
    private  $nom;
    private  $nomUtilisateur;
    private  $motDePasse;
    private  $email;
    private  $telephone;
    private  $photoProfil;

    public function __construct($id, $premon, $nom, $nomUtilisateur, 
     $motDePasse, $email, $telephone, $photoProfil)
    {
        $this->id = $id;
        $this->premon = $premon;
        $this->nom = $nom;
        $this->nomUtilisateur = $nomUtilisateur;
        $this->motDePasse = $motDePasse;
        $this->email = $email;
        $this->telephone = $telephone;
        $this->photoProfil = $photoProfil;
    }

    public function getId(){
        return $this->id;
    }

    public function getPrenom(){
        return $this->premon;
    }

    public function getNom(){
        return $this->nom;
    }

    public function getNomUtilisateur(){
        return $this->nomUtilisateur;
    }
    public function getMotDePasse(){
        return $this->motDePasse;
    }

    public function getEmail(){
        return $this->email;
    }

    public function getTelephone(){
        return $this->telephone;
    }

    public function getPhotoProfil(){
        return $this->photoProfil;
    }

    public function __toString()
    {
        return "$this->id, $this->prenom, $this->nom, $this->nomUtilisateur, $this->motDePasse, $this->email, $this->telephone, $this->photoProfil";
    }

}