<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="css/stylesOlivier.css">
    <link rel="stylesheet" href="css/responsive.css">
    <title>Inscription</title>
</head>
<body>
    <header>
        <nav>
            <ul>
                <li><a href="index.php">Accueil</a></li>
            </ul>
        </nav>
    </header>

    <main class="mainFormulaireConnection">
        <?php
            include_once("modele/DAO/userDAO.class.php");
            $userDAO = new UserDAO();

            //Bouton qui s'occupe de l'inscription
            if(isset($_POST["inscription"])){

                $code = $userDAO->nombre_utilisateur() + 1;
                $lastname = $_POST['lastname'];
                $firstname = $_POST['firstname'];
                $username = $_POST['username'];
                $password = $_POST['password'];
                $confirm = $_POST['confirm'];
                $email = $_POST['email'];
                $telephone = $_POST['telephone'];

                $userDAO->creer_utilisateur($code, $lastname, $firstname, $username,
                $password, $email, $telephone, "images/profil_vide.png");
                header('location: connexion.php');
                
            }
            

        ?>

        <section>

            <form action="" id="signupForm" method="post" class="formulaireConnection">

            <div class="container">
                <label for="pnom"><b>Prénom</b></label>
                <input type="text" placeholder="Entrer votre prénom" name="lastname" id="lastname" required>
                <br><br>
                <label for="nom"><b>Nom de famille</b></label>
                <input type="text" placeholder="Entrer votre nom de famille" name="firstname" id="firstname" required>
                <br><br>
                <label for="uname"><b>Nom d'utilisateur</b></label>
                <input type="text" placeholder="Entrer votre nom d'utilisateur" name="username" id="username" required>
                <br><br>
                <label for="psw"><b>Mot de passe</b></label>
                <input type="password" placeholder="Entrer votre mot de passe" name="password" id="password" required>
                <br><br>
                <label for="psw2"><b>Confirmer le mot de passe</b></label>
                <input type="password" placeholder="Confirmer votre mot de passe" name="confirm" id="confirm" required>
                <br><br>
                <input type="checkbox" id="show-password">Montrer le mot de passe
                <br><br>
                <label for="email"><b>Email</b></label>
                <input type="text" placeholder="Entrer votre adresse électronique" name="email" id="email" required>
                <br><br>
                <label for="phone"><b>Numéro de téléphone</b></label>
                <input type="text" placeholder="Entrer votre numéro de téléphone" name="telephone" id="telephone" required>
                <br><br>
                <button type="submit" name="inscription">Inscrivez-vous!</button>
            </div>

            <div class="container">
                <a href="connexion.php">Déjà inscrit!</a>
            </div>

            </form>
        </section>

    </main>

    <footer>
        <p>Olivier Montel Philippe</p>
        <p>Numéro de téléphone: 514-555-555</p>
        <p>Courriel: dfgd@hotmail.com</p>
    </footer>
    <!-- JAVA SCRIPTS -->
    <?php
    include_once('vue/inclusions/jsScript.php');
    ?>
</body>
</html>