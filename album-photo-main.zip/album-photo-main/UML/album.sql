-- phpMyAdmin SQL Dump
-- version 4.5.4.1
-- http://www.phpmyadmin.net
--
-- Client :  localhost
-- Généré le :  Mar 20 Décembre 2022 à 02:53
-- Version du serveur :  10.5.8-MariaDB
-- Version de PHP :  5.6.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `album`
--

-- --------------------------------------------------------

--
-- Structure de la table `comment`
--

CREATE TABLE `comment` (
  `code` int(10) NOT NULL,
  `code_photo` int(50) NOT NULL,
  `auteur` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `auteur_photo` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `message` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Contenu de la table `comment`
--

INSERT INTO `comment` (`code`, `code_photo`, `auteur`, `auteur_photo`, `message`) VALUES
(1, 6, 'BigSmoke', 'CJ', 'Belle voiture!'),
(2, 2, 'CJ', 'BigSmoke', 'T bo :)'),
(3, 2, 'BigSmoke', 'BigSmoke', 'Merci CJ :)'),
(4, 6, 'BigSmoke', 'CJ', 'fgdfgghgfhjghgjhhjk'),
(5, 2, 'BigSmoke', 'BigSmoke', 'Nice'),
(6, 6, 'BigSmoke', 'CJ', 'gfgfghfg'),
(7, 8, 'BigSmoke', 'CJ', 'Nice house!'),
(8, 2, 'BigSmoke', 'BigSmoke', 'Nice'),
(9, 6, 'BigSmoke', 'CJ', 'Nice'),
(10, 6, 'BigSmoke', 'CJ', 'yo'),
(11, 7, 'BigSmoke', 'BetterCallSaul', 'Nice'),
(12, 7, 'BigSmoke', 'BetterCallSaul', 'Cool');

-- --------------------------------------------------------

--
-- Structure de la table `friend`
--

CREATE TABLE `friend` (
  `code` int(50) NOT NULL,
  `transmitter` text COLLATE utf8_unicode_ci NOT NULL,
  `requester` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Contenu de la table `friend`
--

INSERT INTO `friend` (`code`, `transmitter`, `requester`) VALUES
(1, 'BigSmoke', 'CJ'),
(2, 'BigSmoke', 'Nikolai255');

-- --------------------------------------------------------

--
-- Structure de la table `friendrequest`
--

CREATE TABLE `friendrequest` (
  `code` int(50) NOT NULL,
  `transmitter` text COLLATE utf8_unicode_ci NOT NULL,
  `requester` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Contenu de la table `friendrequest`
--

INSERT INTO `friendrequest` (`code`, `transmitter`, `requester`) VALUES
(1, 'BigShaq', 'BigSmoke');

-- --------------------------------------------------------

--
-- Structure de la table `like_table`
--

CREATE TABLE `like_table` (
  `code` int(11) NOT NULL,
  `code_photo_like` int(11) NOT NULL,
  `like_auteur` varchar(50) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Contenu de la table `like_table`
--

INSERT INTO `like_table` (`code`, `code_photo_like`, `like_auteur`) VALUES
(1, 6, 'Nikolai255'),
(2, 8, 'BigSmoke');

-- --------------------------------------------------------

--
-- Structure de la table `photo`
--

CREATE TABLE `photo` (
  `code` int(10) NOT NULL,
  `autor` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `image` text COLLATE utf8_unicode_ci NOT NULL,
  `nbLike` int(10) NOT NULL,
  `statut` varchar(50) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Contenu de la table `photo`
--

INSERT INTO `photo` (`code`, `autor`, `image`, `nbLike`, `statut`) VALUES
(1, 'BigSmoke', 'https://upload.wikimedia.org/wikipedia/commons/4/47/Hamburger_%28black_bg%29.jpg', 0, 'public'),
(2, 'BigSmoke', 'https://pbs.twimg.com/profile_images/1170617216770945025/k_jwUsPU_400x400.jpg', 0, 'public'),
(3, 'BigSmoke', 'https://preview.redd.it/kj68zia7a0f51.jpg?auto=webp&s=39bd18945bfa08cc0f2df44aafc93551f3af4aac', 0, 'public'),
(4, 'BigSmoke', 'https://img.gta5-mods.com/q95/images/gta-san-andreas-freight-train-replace/db1d6f-20171103234823_1.jpg', 0, 'private'),
(5, 'BigSmoke', 'https://www.bardown.com/polopoly_fs/1.712740!/fileimage/httpImage/image.png_gen/derivatives/landscape_620/intel-youtube.png', 0, 'protected'),
(6, 'CJ', 'https://www.lamborghini.com/sites/it-en/files/DAM/lamborghini/facelift_2019/models_gw/2022/08_19_urus_perf/s/gate_models_s_03_m.jpg', 1, 'public'),
(7, 'BetterCallSaul', 'images/photos/IMG-6394ce1e2b46e9.35333718.jpg', 0, 'public'),
(8, 'CJ', 'images/photos/IMG-639e3491df19b8.57585827.jpg', 1, 'protected'),
(9, 'Nikolai255', 'images/photos/IMG-639f94ac8c7e56.87386802.png', 0, 'public'),
(10, 'BigShaq', 'images/photos/IMG-639fb396b64779.21877188.png', 0, 'public');

-- --------------------------------------------------------

--
-- Structure de la table `user`
--

CREATE TABLE `user` (
  `code` int(10) NOT NULL,
  `firstname` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `lastname` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `username` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `telephone` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `profile_picture` text COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Contenu de la table `user`
--

INSERT INTO `user` (`code`, `firstname`, `lastname`, `username`, `password`, `email`, `telephone`, `profile_picture`) VALUES
(1, 'Melvin', 'Harris', 'BigSmoke', '123', 'bigsmoke@gmail.com', '4395557674', 'images/photos_profil/IMG-63a0d154b254a5.11855614.jpg'),
(2, 'Carl', 'Johnson', 'CJ', '321', 'cj@gmail.com', '4395557676', 'images/cj.png'),
(3, 'Niko', 'Bellic', 'Nikolai255', '123', 'hghjh@gmail.comjj', '4395557676', 'images/niko.png'),
(4, 'Saul', 'Goodman', 'BetterCallSaul', '123', 'asdasd@gmail.com', '4556678989', 'images/photos_profil/IMG-6393ffd14b5111.29133221.png'),
(5, 'admin', 'admin', 'admin', '123', 'asdasd@gmail.com', '4556678989', 'images/photos_profil/IMG-6396c39c34a3e4.04814918.png'),
(6, 'Shaquille', 'Oneal', 'BigShaq', '12345678', 'asdasd@gmail.com', '4556678989', 'images/photos_profil/IMG-639fb5d579f041.55734489.png');

--
-- Index pour les tables exportées
--

--
-- Index pour la table `comment`
--
ALTER TABLE `comment`
  ADD PRIMARY KEY (`code`);

--
-- Index pour la table `friend`
--
ALTER TABLE `friend`
  ADD PRIMARY KEY (`code`);

--
-- Index pour la table `friendrequest`
--
ALTER TABLE `friendrequest`
  ADD PRIMARY KEY (`code`);

--
-- Index pour la table `like_table`
--
ALTER TABLE `like_table`
  ADD PRIMARY KEY (`code`);

--
-- Index pour la table `photo`
--
ALTER TABLE `photo`
  ADD PRIMARY KEY (`code`);

--
-- Index pour la table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`code`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
