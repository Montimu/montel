<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="css/stylesOlivier.css">
    <link rel="stylesheet" href="css/responsive.css">
    <title>Administrateur</title>
</head>
<body>
    <!-- HEADER -->
    <?php
    require_once('vue\inclusions\selectionHeader.php');
    include_once("modele/DAO/photoDAO.class.php");
    include_once("modele\DAO\commentDAO.class.php");
    include_once("modele\DAO\likeDAO.class.php");
    include_once('modele/DAO/friendDAO.class.php');
    include_once('modele/DAO/friendRequestDAO.class.php');
    $photoDAO = new PhotoDAO();
    $commentDAO = new CommentDAO();
    $likeDAO = new LikeDAO();
    $friendDAO = new FriendDAO();
    $friendRequestDAO = new FriendRequestDAO();
    ?>
    <!-- HEADER -->

    <main class="mainFormulaireConnection">
            
        <section>
            <?php 
                include_once('modele/DAO/userDAO.class.php');
                $userDAO = new UserDAO();
                $liste_user = $userDAO->afficher_utilisateur();
                $actionButton = "ajouter";
                $actionTxt = "Ajouter un utilisateur!";
                $id=null;
                $prenom = null;
                $nom = null;
                $nomUtilisateur = null;
                $mdp = null;
                $prenom = null;
                $mail = null;
                $ndt = null;

                //Récuperer information utilisateur avec le lien "Modifier l'utilisateur!"
                if (isset($_REQUEST['id']) and $_REQUEST['id'] !==null and $_REQUEST['id'] >= 1)
                {
                    $actionTxt = "Modifier un utilisateur!";
                    $actionButton = "modifier";
                    $id=$_REQUEST['id'];
                    $prenom = $userDAO->get_utilisateur_valeur($_REQUEST['id'], "prenom");
                    $nom = $userDAO->get_utilisateur_valeur($_REQUEST['id'], "nom");
                    $nomUtilisateur = $userDAO->get_utilisateur_valeur($_REQUEST['id'], "nomUtilisateur");
                    $mdp = $userDAO->get_utilisateur_valeur($_REQUEST['id'], "motDePasse");
                    $mail = $userDAO->get_utilisateur_valeur($_REQUEST['id'], "email");
                    $ndt = $userDAO->get_utilisateur_valeur($_REQUEST['id'], "telephone");     
                }

                if(isset($_REQUEST['action'])){
                    switch($_REQUEST['action']){
                        case 'ajouter' :
                            //Créer un utilisateur
                            if(isset($_REQUEST['btnOk'])){
                                $code = $userDAO->nombre_utilisateur() + 1;
                                $lastname = $_REQUEST['lastname'];
                                $firstname = $_REQUEST['firstname'];
                                $username = $_REQUEST['username'];
                                $password = $_REQUEST['password'];
                                $email = $_REQUEST['email'];
                                $telephone = $_REQUEST['telephone'];
                                $userDAO->creer_utilisateur($code, $lastname, $firstname, $username, 
                                $password, $email, $telephone, "images/profil_vide.png");
                                header('location: administrateur.php');
                            }
                        break;
                        case 'modifier' :
                            //Modifier un utilisateur
                            if(isset($_REQUEST['btnOk'])){
                                $vieuxNom = $nomUtilisateur;
                                if($userDAO->trouver_utilisateur($vieuxNom)){
                                    $lastname = $_REQUEST['lastname'];
                                    $firstname = $_REQUEST['firstname'];
                                    $username = $_REQUEST['username'];
                                    $password = $_REQUEST['password'];
                                    $email = $_REQUEST['email'];
                                    $telephone = $_REQUEST['telephone'];
                                    $userDAO->modifier_utilisateur($id, $lastname, $firstname, $username, 
                                    $password, $email, $telephone);
                                    $photoDAO->modifier_auteur_photo($vieuxNom, $username);
                                    $commentDAO->modifier_auteur_comment($vieuxNom, $username);
                                    $likeDAO->modifier_auteur_like($vieuxNom, $username);
                                    $friendDAO->modifier_auteur_friend($vieuxNom, $username);
                                    $friendRequestDAO->modifier_auteur_friend_request($vieuxNom, $username);
                                    header('location: administrateur.php');
                                }
                                
                                else{
                                    header('location: administrateur.php');
                                }
                            }
                        break;
                    }
                }  

                //Supprimer un utilisateur
                if (isset($_GET['supprimer']))
                {
                    $userDAO->supprimer_utilisateur($_GET['supprimer']);
                    header('location: administrateur.php');
                }

                //Annuler
                if (isset($_REQUEST['btnAnnuler']))
                {
                    $id=null;
                    $prenom = null;
                    $nom = null;
                    $nomUtilisateur = null;
                    $mdp = null;
                    $prenom = null;
                    $mail = null;
                    $ndt = null;
                    header('location: administrateur.php');
                }

             ?>

            <form action="administrateur.php" id="signupForm" method="post" class="formulaireConnection">

                <div class="container">
                    <label for="uname"><b>Prénom</b></label>
                    <input type="text" placeholder="Entrer votre prénom" name="lastname" value="<?=$prenom?>" required>
                    <input type="hidden" name="action" value="<?=$actionButton?>" />
					<input type="hidden" name="id" value="<?=$id?>" />
                    <br><br>
                    <label for="uname"><b>Nom de famille</b></label>
                    <input type="text" placeholder="Entrer votre nom de famille" name="firstname" value="<?=$nom?>" required>
                    <br><br>
                    <label for="uname"><b>Nom d'utilisateur</b></label>
                    <input type="text" placeholder="Entrer votre nom d'utilisateur" name="username" value="<?=$nomUtilisateur?>" required>
                    <br><br>
                    <label for="psw"><b>Mot de passe</b></label>
                    <input type="password" placeholder="Entrer votre mot de passe" name="password" value="<?=$mdp?>" required>
                    <br><br>
                    <label for="uname"><b>Email</b></label>
                    <input type="text" placeholder="Entrer votre adresse électronique" name="email" value="<?=$mail?>" required>
                    <br><br>
                    <label for="uname"><b>Numéro de téléphone</b></label>
                    <input type="text" placeholder="Entrer votre numéro de téléphone" name="telephone" value="<?=$ndt?>" required>
                    <br><br>
                    <button type="submit" name="btnOk"><?=$actionTxt?></button>
                    <button type="submit" name="btnAnnuler">Annuler</button>
                </div>

                <div class="container">
                </div>

            </form>

            <?php 
            echo "Nombre d'utilisateur: " . $userDAO->nombre_utilisateur();
            ?>

            <h1>Liste des utilisateurs</h1>
                <!-- Boucle for qui récupère tout les utilisateurs contenus dans la base de donnée -->
                <div class="liste_utilisateur">
                    <?php foreach($liste_user as $user){ ?>
                        <div class="row_utilisateur">
                            <a href="profilPublique.php?user=<?=$user->getNomUtilisateur();?>"><?php echo $user->getNomUtilisateur();?></a>
                            <a href="?action=modifier&id=<?=$user->getId();?>">Modifier l'utilisateur</a>
                            <a href="?supprimer=<?php echo $user->getId();?>">Supprimer l'utilisateur</a>
                        </div>
                    <?php } ?>
                </div>
        
        </section>
    </main>

    <footer>
        <p>Olivier Montel Philippe</p>
        <p>Numéro de téléphone: 514-555-555</p>
        <p>Courriel: dfgd@hotmail.com</p>
    </footer>
    <!-- JAVA SCRIPTS -->
    <?php
    include_once('vue/inclusions/jsScript.php');
    ?>
</body>
</html>