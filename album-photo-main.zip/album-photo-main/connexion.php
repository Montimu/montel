<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="css/stylesOlivier.css">
    <link rel="stylesheet" href="css/responsive.css">
    <title>Connection</title>
</head>
<body>
        <?php
            include_once('modele/DAO/userDAO.class.php');
            if (!ISSET($_SESSION)){
                session_start();
            }

            $userDAO = new UserDAO();
            $_SESSION["rechercheListe"] = [];
            $_SESSION['utilisateur'] = null;
            $cnx = (isset($_POST['username']) and isset($_POST['password']));

            if(isset($_REQUEST['btnCnx'])){
                //Vérification si les champs username et password sont définis
                if($cnx){
                    $username = $_POST['username'];
                    $password = $_POST['password'];
                    //Vérification si l'utilisateur connecté est un admin
                    if($username == 'admin' and $password == '123'){
                        $_SESSION['utilisateur'] = $username;
                        header('location: administrateur.php');
                    }
                    //Vérification si l'utilisateur existe dans la base de donnée
                    else if($userDAO->rechercher_utilisateur($username, $password)){
                        $_SESSION['utilisateur'] = $username;
                        header('location: index.php');
                    }

                    else{
                        header('location: connexion.php');
                    }
                  }
            }
        ?>
    
    <header>
        <nav>
            <ul>
                <li><a href="index.php">Accueil</a></li>
            </ul>
        </nav>
    </header>

    <main class="mainFormulaireConnection">

        <section>

            <form action="connexion.php" id="loginForm" method="post" class="formulaireConnection">

            <div class="container">
                <label for="uname"><b>Nom d'utilisateur</b></label>
                <input type="text" placeholder="Entrer votre nom d'utilisateur" name="username" required>
                <br><br>
                <label for="psw"><b>Mot de passe</b></label>
                <input type="password" placeholder="Entrer votre mot de passe" id="password" name="password" required>
                <br><br>
                <input type="checkbox" id="show-password">Montrer le mot de passe
                <br><br>
                <button type="submit" name="btnCnx">Connectez-vous!</button>
            </div>

            <div class="container">
                <a href="inscription.php">Inscrivez-vous!</a>
            </div>

            </form>
        </section>

    </main>

    <footer>
        <p>Olivier Montel Philippe</p>
        <p>Numéro de téléphone: 514-555-555</p>
        <p>Courriel: dfgd@hotmail.com</p>
    </footer>
</body>
<!-- JAVA SCRIPTS -->
<?php
include_once('vue/inclusions/jsScript.php');
?>
</html>