<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css"/>
    <link rel="stylesheet" href="css/stylesKoukio.css">
    <link rel="stylesheet" href="css/responsive.css">
    <title>Profil</title>
</head>
<body>
    <!-- HEADER -->
    <?php
    require_once('vue\inclusions\selectionHeader.php');
    include_once("modele/DAO/photoDAO.class.php");
    include_once('modele/DAO/friendDAO.class.php');
    include_once('modele/DAO/friendRequestDAO.class.php');
    $photoDAO = new PhotoDAO();
    $friendDAO = new FriendDAO();
    $friendRequestDAO = new FriendRequestDAO();
    $liste_photo = $photoDAO->get_photo_utilisateur($nomUtilisateur, "");
    $liste_amis = $friendDAO->afficher_amis($nomUtilisateur);
    ?>
    <!-- HEADER -->

    <main>
        <div class="header__wrapper">

            <div class="cols__container">

                <div class="left__col">
                    <div class="img__container">
                        <img src="<?=$photoProfil?>" alt="ciel">
                        <span></span>
                    </div>
                    <h2><?=$nomUtilisateur?></h2>

                    <form action="" class="formChangerPhotoProfil" method="post" enctype="multipart/form-data">
                        <label for="txtPhotoProfil" class="btn btn-primary btn-block btn-outlined">Sélectionner une photo</label>
                        <input type="file" id="txtPhotoProfil" name="btnSelectPhotoProfil" accept="image/*">
                        <input type="submit" name="btnAjoutPhotoProfil" value="Changer">
                    </form>

                    <?php
                    //Les boutons qui s'occupent de changer la photo de profile à partir d'un fichier
                    if(isset($_FILES['btnSelectPhotoProfil']) and isset($_POST['btnAjoutPhotoProfil'])){
                        $profile_name = $_FILES['btnSelectPhotoProfil']['name'];
                        $profile_type = $_FILES['btnSelectPhotoProfil']['type'];
                        $profile_tmp_name = $_FILES['btnSelectPhotoProfil']['tmp_name'];
                        $profile_error = $_FILES['btnSelectPhotoProfil']['error'];
                        $profile_size = $_FILES['btnSelectPhotoProfil']['size'];

                        if($profile_error === 0){
                            $profileType = strtolower(pathinfo($profile_name, PATHINFO_EXTENSION));
                            $profile_allowed_exs = array("jpg", "jpeg", "png");
                            if (in_array($profileType, $profile_allowed_exs)){
                                $new_profile = uniqid("IMG-", true). '.' .$profileType;
                                $lien_photo_profile = 'images/photos_profil/' . $new_profile;

                                $ancienPhotoProfile = $userDAO->get_utilisateur_valeur_avec_username($nomUtilisateur, "photoProfil");
                                if($ancienPhotoProfile != "images/profil_vide.png" ){
                                    unlink($ancienPhotoProfile);
                                }

                                move_uploaded_file($profile_tmp_name, $lien_photo_profile);//Enregistrer l'image dans le dossier images\photos_profil
                                $userDAO->modifier_photo_profil($lien_photo_profile, $nomUtilisateur);
                                $reponse = "Vous avez changer votre photo de profil!";
							    header('location: profil.php?reponseImg=' . $reponse);
                            }
                        else{
                            $reponse = "La photo que vous avez envoyer n'est pas valide!";
                            header('location: profil.php?reponseImg=' . $reponse);
                        }
                        }
                    }
                    ?>
                    
                    <div class="content">
                        <h2>Liste d'amis</h2>
                    </div>

                    <div class="amis">
                    <!-- Boucle for qui récupère tout les amis d'un utilisateur contenus dans la base de donnée -->
                    <?php foreach($liste_amis as $amis){ ?>
                            <!-- Si l'utilisateur connecté est le transmetteur -->
                            <?php if($amis->getTransmetteur() == $nomUtilisateur){?>
                                <?php $photoProfilUser = $userDAO->get_utilisateur_valeur_avec_username($amis->getReceveur(), 'photoProfil');?>
                                <figure>
                                    <img src="<?=$photoProfilUser?>" alt="<?=$amis->getReceveur();?>">
                                    <figcaption><p><a href="profilPublique.php?user=<?=$amis->getReceveur();?>"><?=$amis->getReceveur();?></a></p></figcaption>
                                </figure>
                            <?php } ?>
                            <!-- Si l'utilisateur connecté est le receveur -->
                            <?php if($amis->getReceveur() == $nomUtilisateur){?>
                                <?php $photoProfilUser = $userDAO->get_utilisateur_valeur_avec_username($amis->getTransmetteur(), 'photoProfil');?>
                                <figure>
                                    <img src="<?=$photoProfilUser?>" alt="<?=$amis->getTransmetteur();?>">
                                    <figcaption><p><a href="profilPublique.php?user=<?=$amis->getTransmetteur();?>"><?=$amis->getTransmetteur();?></a></p></figcaption>
                                </figure>
                            <?php } ?>
                        <?php } ?>
                    </div>
                </div>

                <div class="right__col">
                    <h1>Album photo</h1>
                    <div class="photos">
                        <?php foreach($liste_photo as $photo){ ?>
                            <a href="prive.php?photoCode=<?=$photo->getId();?>"><img src="<?=$photo->getImage()?>" alt="Photo de <?=$photo->getAuteur()?>"></a>
                        <?php } ?>
                    </div>

                    <?php
                    //Les boutons qui s'occupent de changer la photo de profile à partir d'un fichier
                    if(isset($_FILES['btnSelectImg']) and isset($_POST['btnAjoutImg'])){
                        /*
                        NOTES: Pour mieux voir les attributs d'un objet files
                        echo "<pre>";
                        print_r($_FILES['btnSelectImg']);
                        echo "</pre>";

                        [name] => spring.jpg
                        [type] => image/jpeg
                        [tmp_name] => C:\Users\Olivier\AppData\Local\Temp\phpF4B3.tmp
                        [error] => 0
                        [size] => 110144
                        */
                        
                        $image_name = $_FILES['btnSelectImg']['name'];
                        $image_type = $_FILES['btnSelectImg']['type'];
                        $image_tmp_name = $_FILES['btnSelectImg']['tmp_name'];
                        $image_error = $_FILES['btnSelectImg']['error'];
                        $image_size = $_FILES['btnSelectImg']['size'];
                        //Vérification s'il y a une erreur
                        if($image_error === 0){
                            //Vérifie la taille de l'image
                            if($image_size > 1000000){
                                $reponse = "La photo est trop gros: " . $image_size . " > 125000";
                                echo "<script> window.location.href='profil.php?reponseImg=" . $reponse . "';</script>";
                            }
                            //Envoie la photo dans la base de donnée
                            else{
                                $imageType = strtolower(pathinfo($image_name, PATHINFO_EXTENSION));
                                $allowed_exs = array("jpg", "jpeg", "png");
                                //Vérifie si l'image est de type JPG, JPEG OU PNG
                                if (in_array($imageType, $allowed_exs)){
                                    $new_image = uniqid("IMG-", true). '.' .$imageType;
                                    $lien_image = 'images/photos/' . $new_image;
                                    move_uploaded_file($image_tmp_name, $lien_image);//Enregistrer l'image dans le dossier images\photos
                                    $idPhoto = $photoDAO->nombre_photo() + 1;
                                    $photoDAO->creer_photo($idPhoto, $nomUtilisateur, $lien_image, 0, "public");
                                    $reponse = "La photo a été enregistré dans votre album photo";
                                    $nooooo = "yess";
                                    echo "<script> window.location.href='profil.php?reponseImg=" . $reponse . "';</script>";
                                }
                                else{
                                    $reponse = "Vous pouvez seulement envoyer des images de type JPG, JPEG ou PNG";
                                    echo "<script> window.location.href='profil.php?reponseImg=" . $reponse . "';</script>";
                                }
                            }
                        }

                        else{
                            $reponse = "Il y a eu une erreur";
                            echo "<script> window.location.href='profil.php?reponseImg=" . $reponse . "';</script>";
                        }

                    }
                    ?>

                    <form action="" class="formAjoutImage" method="post" enctype="multipart/form-data">
                        <label for="img">Ajouter une image:</label>
                        <input type="file" id="img" name="btnSelectImg" accept="image/*">
                        <input type="submit" name="btnAjoutImg" value="Ajouter">
                        <p>Réponse: <span><?=$_GET['reponseImg'];?></span></p>
                    </form>
                </div>

            </div>

        </div>
    </main>

    <footer>
        <p>Olivier Montel Philippe</p>
        <p>Numéro de téléphone: 514-555-555</p>
        <p>Courriel: dfgd@hotmail.com</p>
    </footer>
</body>
</html>