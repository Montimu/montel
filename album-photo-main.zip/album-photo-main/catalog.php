<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="css/stylesOlivier.css">
    <link rel="stylesheet" href="css/responsive.css">

    <title>Catalogue</title>
</head>
<body>
    <!-- HEADER -->
    <?php
    require_once('vue\inclusions\selectionHeader.php');
    ?>
    <!-- HEADER -->

    <main>
        <?php
        include_once("modele/DAO/photoDAO.class.php");
        $photoDAO = new PhotoDAO();
        $liste_photo = $photoDAO->afficher_photo_publique();
        ?>
        <section class="catalog">
            <!-- Boucle for qui récupère tout les photos contenues dans la base de donnée -->
            <?php foreach($liste_photo as $photo){ ?>
                <figure>
                    <a href="publiques.php?photoCode=<?=$photo->getId();?>"><img src=<?php echo $photo->getImage();?> alt="photo : <?php echo $photo->getAuteur();?>"></a>
                    <figcaption>Auteur: <a href="profilPublique.php?user=<?=$photo->getAuteur();?>"><?php echo $photo->getAuteur();?></a></figcaption>
                </figure>
            <?php } ?>
            
        </section>
    </main>

    <footer class="footerCatalog">
        <p>Olivier Montel Philippe</p>
        <p>Numéro de téléphone: 514-555-555</p>
        <p>Courriel: dfgd@hotmail.com</p>
    </footer>
</body>
</html>