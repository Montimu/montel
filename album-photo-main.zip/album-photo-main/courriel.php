<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="css/stylesOlivier.css">
    <link rel="stylesheet" href="css/responsive.css">
    <title>Courriel</title>
</head>
<body class="courriel-body">
    <!-- HEADER -->
    <?php
    require_once('vue\inclusions\selectionHeader.php');
    include_once("modele/DAO/photoDAO.class.php");
    include_once('modele/DAO/friendDAO.class.php');
    include_once('modele/DAO/friendRequestDAO.class.php');
    $photoDAO = new PhotoDAO();
    $friendDAO = new FriendDAO();
    $friendRequestDAO = new FriendRequestDAO();
    $liste_demande_ami = $friendRequestDAO->afficher_demande_ami($nomUtilisateur);
    ?>
    <!-- HEADER -->

    <main>
        <section>

            <h1>Liste des demandes d'amis</h1>

            <?php
            //Vérification s'il y a des demandes d'amis
            if(empty($liste_demande_ami)){
                echo "<h3>Rien à signaler pour le moment :)</h3>";
            }
            ?>

            <?php
            //Bouton qui accepte la demande d'ami
            if(isset($_GET['btnAccepter'])){
                $idAmi = $friendDAO->nombre_amis() + 1;
                $friendDAO->creer_un_ami($idAmi, $nomUtilisateur, $_GET['btnAccepter']);
                $friendRequestDAO->supprimer_demande($_GET['btnAccepter'], $nomUtilisateur);
                header('location: courriel.php');
            }
            //Bouton qui refuse la demande d'ami
            if(isset($_GET['btnRefuser'])){
                $friendRequestDAO->supprimer_demande($_GET['btnRefuser'], $nomUtilisateur);
                header('location: courriel.php');
            }
            ?>
            <!-- Liste qui récupère les demandes d'ami contenues dans la base de donnée -->
            <?php foreach($liste_demande_ami as $demande){ ?>
                <?php
                $receveurPP = $userDAO->get_utilisateur_valeur_avec_username($demande->getTransmetteur(), "photoProfil");
                $transmetteurNom = $demande->getTransmetteur();
                ?>
                <div class="container courriel">
                    <div>
                        <figure>
                            <img src="<?=$receveurPP?>" alt="">
                            <figcaption><a href="profilPublique.php?user=<?=$transmetteurNom?>"><?=$transmetteurNom?></a></figcaption>
                        </figure>
                    </div>
                    <div>
                        <a href="?btnAccepter=<?=$transmetteurNom?>"><img src="images/check_button.png" alt="bouton accepter"></a>
                    </div>
                    <div>
                        <a href="?btnRefuser=<?=$transmetteurNom?>"><img src="images/x_button.png" alt="bouton refuser"></a>
                    </div>
                </div>
            <?php } ?>

        </section>
    </main>

    <footer>
        <p>Olivier Montel Philippe</p>
        <p>Numéro de téléphone: 514-555-555</p>
        <p>Courriel: dfgd@hotmail.com</p>
    </footer>
</body>

</html>