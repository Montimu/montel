
// Récupération des figure du diaporama
var images = $('#slideshow img');
var figure = $('#slideshow figure');

// Index de l'image active
var index = 0;

// Affichage de l'image active
$(figure[index]).addClass('active');

// Fonction pour passer à l'image suivante
function next() {
  // Masquage de l'image active
  $(figure[index]).removeClass('active');

  // Mise à jour de l'index
  index = (index + 1) % figure.length;

  // Affichage de l'image suivante
  $(figure[index]).hide();
  $(figure[index]).fadeIn(2000);
  $(figure[index]).addClass('active');
}

// Fonction pour passer à l'image précédente
function prev() {
  // Masquage de l'image active
  $(figure[index]).removeClass('active');

  // Mise à jour de l'index
  index = (index - 1 + figure.length) % figure.length;

  // Affichage de l'image précédente
  $(figure[index]).addClass('active');
}

// Démarrage du diaporama (passage à l'image suivante toutes les 3 secondes)
setInterval(function () {next()}, 7000)
