$(document).ready(function(){

    //Checkbox qui permet de montrer un mot de passe
    $("#show-password").click(function() {
        if ($(this).is(":checked")) {
          $("#password").attr("type", "text");
          $("#confirm").attr("type", "text");
        } else {
          $("#password").attr("type", "password");
          $("#confirm").attr("type", "password");        
        }
      });

    //Methode qui valide le numéro de téléphone
    jQuery.validator.addMethod("phone", function(phone_number, element) {
        phone_number = phone_number.replace(/\s+/g, "");
        return this.optional(element) || phone_number.length > 9 && 
        phone_number.match(/^(\+?1-?)?(\([2-9]\d{2}\)|[2-9]\d{2})-?[2-9]\d{2}-?\d{4}$/);
    }, "Veuillez saisir un numéro de téléphone valide");

    //Method qui valide l'email
    jQuery.validator.addMethod("email",function (courriel) {
          var patron = /^[a-z][a-z0-9]*((\.|\-)?[a-z0-9]+)*@([a-z0-9]+\.)+[a-z]+$/i;
          return patron.test(courriel.trim());
      
        },
        "Veuillez saisir un email valide"
      );

    // Formulaire connexion validation
    $("#loginForm").validate({
 
       rules:{
          username: {
            required: true
          },
          password: {
            required: true
          },
       },
 
       messages:{
          username : "Veuillez saisir votre nom",
          password : "Veuillez saisir votre mot de passe"
       }
    });

    //Formulaire inscription validation
    $("#signupForm").validate({
 
        rules:{
            lastname:{
                required: true,
                minlength: 3,
                maxlength: 16,
            },
            firstname:{
                required: true,
                minlength: 3,
                maxlength: 16,
            },
            username:{
                required: true,
                minlength: 3,
                maxlength: 16,
            },
            password:{
                required: true,
                minlength: 8,
            },
            confirm:{
                required: true,
                minlength: 6,
                maxlength: 16,
                equalTo: "#password",
            },
            email:{
                required: true,
                email: true,
            },
            telephone:{
                required: true,
                phone: true,
            },
        },
  
        messages:{
            lastname:{
                required: "Veuillez saisir votre prénom",
                minlength: "Votre prénom doit contenir 3 à 16 caractères",
                maxlength: "Votre prénom doit contenir 3 à 16 caractères",
            },
            firstname:{
                required: "Veuillez saisir votre nom de famille",
                minlength: "Votre nom doit contenir 3 à 16 caractères",
                maxlength: "Votre nom doit contenir 3 à 16 caractères",
            },
            username:{
                required: "Veuillez saisir votre nom d'utilisateur",
                minlength: "Votre pseudo doit contenir 3 à 16 caractères",
                maxlength: "Votre pseudo doit contenir 3 à 16 caractères",
            },
            password:{
                required: "Veuillez saisir votre mot de passe",
                minlength: "Votre mot de passe doit contenir au minimum 8 charactères",
            },
            confirm:{
                required: "Veuillez confirmer votre mot de passe",
                minlength: "Votre confirmation doit contenir au minimum 8 charactères",
                equalTo: "Votre confirmation ne correspond pas au mot de passe",
            },
            email:{
                required: "Veuillez saisir un email valide",
                email: "Veuillez saisir un email valide!!!!!!!!",
            },
            telephone:{
                required: "Veuillez saisir un numéro de téléphone valide",
                phone: "Veuillez saisir un numéro de téléphone valide!!!!!!",
            },
        }
     });
 });