<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css"/>
    <link rel="stylesheet" href="css/stylesKoukio.css">
    <link rel="stylesheet" href="css/responsive.css">
    <title>Profil</title>
</head>
<body>
    <?php
    //HEADER
    require_once('vue\inclusions\selectionHeader.php');
    //HEADER
    include_once("modele/DAO/photoDAO.class.php");
    include_once('modele/DAO/friendDAO.class.php');
    include_once('modele/DAO/friendRequestDAO.class.php');
    $photoDAO = new PhotoDAO();
    $friendDAO = new FriendDAO();
    $friendRequestDAO = new FriendRequestDAO();
    $nomUtilisateur2 = $_GET["user"];
    $liste_amis = $friendDAO->afficher_amis($nomUtilisateur2);

    //Au cas ou l'utilisateur n'existe pas
    if(!$userDAO->trouver_utilisateur($nomUtilisateur2)){
        header('location: erreur.php');
    }

    //Vérifie si la session n'est pas null
    if(!empty($nomUtilisateur)){
        //Si le nom de l'utilisateur connecté est égale à l'utilisateur public. Le lien le ramènera dans sa page de profil privé.
        if($nomUtilisateur2 == $nomUtilisateur){
            header('location: profil.php?reponseImg=');
        }

        else{
            //Affiche les photos public et protégé si l'utilisateur ( est transmetteur) connecté est ami avec un utilisateur
            if($friendDAO->rechercher_ami($nomUtilisateur, $nomUtilisateur2, "transmetteur")){
                $liste_photo = $photoDAO->get_photo_utilisateur($nomUtilisateur2, "protected");
            }
            //Affiche les photos public et protégé si l'utilisateur (est receveur) connecté est ami avec un utilisateur
            elseif($friendDAO->rechercher_ami($nomUtilisateur, $nomUtilisateur2, "receveur")){
                $liste_photo = $photoDAO->get_photo_utilisateur($nomUtilisateur2, "protected");
            }
            //Affiche les photos public si l'utilisateur connecté n'est pas amis avec l'utilisateur
            else{
                $liste_photo = $photoDAO->get_photo_utilisateur($nomUtilisateur2, "public");
            }
            $photoProfil2 = $userDAO->get_utilisateur_valeur_avec_username($nomUtilisateur2, "photoProfil");
        }
    }

    //Affiche suelement les photos publiques, car la session est donc l'utilisateur est un visisteur
    else{
        $liste_photo = $photoDAO->get_photo_utilisateur($nomUtilisateur2, "public");
        $photoProfil2 = $userDAO->get_utilisateur_valeur_avec_username($nomUtilisateur2, "photoProfil");
    }
    ?>

    <main>
        <div class="header__wrapper">

            <div class="cols__container">

                <div class="left__col">
                    <div class="img__container">
                        <img src="<?=$photoProfil2?>" alt="ciel">
                        <span></span>
                    </div>
                    
                    <h2><?=$nomUtilisateur2?></h2>

                    <?php
                    //Vérifie si la session utilisateur n'est pas null
                    if(!empty($nomUtilisateur)){
                        //Vérifi si l'utilisateur connecté (est transmetteur) est déjà ami avec l'utilisateur. Dans ce cas il pourra le retirer en tant qu'ami
                        if($friendDAO->rechercher_ami($nomUtilisateur, $nomUtilisateur2, "transmetteur")){
                            $btnAmiTxt = "Retirer";
                            if(isset($_POST['btnAmi'])){
                                $friendDAO->supprimer_ami($nomUtilisateur, $nomUtilisateur2, "transmetteur");
                                header('refresh: 0');
                            }
                        }
                        //Vérifi si l'utilisateur connecté (receveur) est déjà ami avec l'utilisateur. Dans ce cas il pourra le retirer en tant qu'ami
                        else if($friendDAO->rechercher_ami($nomUtilisateur, $nomUtilisateur2, "receveur")){
                            $btnAmiTxt = "Retirer";
                            if(isset($_POST['btnAmi'])){
                                $friendDAO->supprimer_ami($nomUtilisateur, $nomUtilisateur2, "receveur");
                                header('refresh: 0');
                            }
                        }
                        //Vérifi si l'utilisateur connecté a déjà envoyé une demande d'ami. Dans ce cas il pourra annuler la demande
                        else if($friendRequestDAO->rechercher_demande_ami($nomUtilisateur, $nomUtilisateur2)){
                            $btnAmiTxt = "Annuler";
                            if(isset($_POST['btnAmi'])){
                                $friendRequestDAO->supprimer_demande($nomUtilisateur, $nomUtilisateur2);
                                header('refresh: 0');
                            }
                        }
                        //L'utilisateur connecté pourra envoyer une demande d'ami à l'utilisateur. Si tout les cas précédants sont faux
                        else{
                            $btnAmiTxt = "Ajouter";
                            if(isset($_POST['btnAmi'])){
                                $idDemandeAmi = $friendRequestDAO->nombre_demande_amis() + 1;
                                $friendRequestDAO->creer_une_demande_ami($idDemandeAmi, $nomUtilisateur, $nomUtilisateur2);
                                header('refresh: 0');
                            }
                        }
                    }
                    else{
                        $btnAmiTxt = "Ajouter";
                    }
                    ?>

                    <form action="" method="post">
                        <button name="btnAmi"><?=$btnAmiTxt?></button>
                    </form>
                    
                    <div class="content">
                        <h2>Liste d'amis</h2>
                    </div>

                    <div class="amis">
                        <!-- Boucle for qui récupère tout les amis d'un utilisateur contenus dans la base de donnée -->
                        <?php foreach($liste_amis as $amis){ ?>
                            <?php if($amis->getTransmetteur() == $nomUtilisateur2){?>
                                <?php $photoProfilUser = $userDAO->get_utilisateur_valeur_avec_username($amis->getReceveur(), 'photoProfil');?>
                                <figure>
                                    <img src="<?=$photoProfilUser?>" alt="<?=$amis->getReceveur();?>">
                                    <figcaption><p><a href="profilPublique.php?user=<?=$amis->getReceveur();?>"><?=$amis->getReceveur();?></a></p></figcaption>
                                </figure>
                            <?php } ?>
                            <?php if($amis->getReceveur() == $nomUtilisateur2){?>
                                <?php $photoProfilUser = $userDAO->get_utilisateur_valeur_avec_username($amis->getTransmetteur(), 'photoProfil');?>
                                <figure>
                                    <img src="<?=$photoProfilUser?>" alt="<?=$amis->getTransmetteur();?>">
                                    <figcaption><p><a href="profilPublique.php?user=<?=$amis->getTransmetteur();?>"><?=$amis->getTransmetteur();?></a></p></figcaption>
                                </figure>
                            <?php } ?>
                        <?php } ?>
                    </div>
                </div>

                <div class="right__col">
                    <h1>Album photo</h1>
                    <div class="photos">
                        <!-- Boucle for qui récupère tout les photos d'un utilisateur contenus dans la base de donnée -->
                        <?php foreach($liste_photo as $photo){ ?>
                            <a href="publiques.php?photoCode=<?=$photo->getId();?>"><img src="<?=$photo->getImage()?>" alt="Photo de <?=$photo->getAuteur()?>"></a>
                        <?php } ?>
                    </div>

                </div>

            </div>

        </div>
    </main>

    <footer>
        <p>Olivier Montel Philippe</p>
        <p>Numéro de téléphone: 514-555-555</p>
        <p>Courriel: dfgd@hotmail.com</p>
    </footer>
</body>
</html>