<header>
<form action="" id="formRecherche" method="post"></form>
    <?php
    include_once('modele/DAO/userDAO.class.php');
    $userDAO = new UserDAO();
    $nomUtilisateur = $_SESSION["utilisateur"];
    $photoProfil = $userDAO->get_utilisateur_valeur_avec_username($nomUtilisateur, "photoProfil");

    if(isset($_REQUEST["rechercher"])){
        
        $_SESSION["rechercheListe"] = $userDAO->afficher_recherche_utilisateur($_POST['champRecherche']);
        header('location: pageDeRecherche.php');

    }
    ?>
        <nav>
            <ul>
                <li><a href="index.php">Accueil</a></li>
                <li><a href="catalog.php">Catalogue</a></li>
                <li><a href="profil.php?reponseImg=">Profil</a></li>
                <li><a href="courriel.php">Courriel</a></li>
                <li><input form="formRecherche" type="text" name="champRecherche" placeholder="Rechercher un utilisateur"></li>
                <li><button form="formRecherche" type="submit" name="rechercher">Rechercher</button></li>
                <li><a href="connexion.php">Déconnexion</a></li>
				<li><a href="profil.php?reponseImg="><img src="<?=$photoProfil?>" alt=""></a></li>
            </ul>
        </nav>
</header>