<?php
    include_once('modele/DAO/userDAO.class.php');
    //Nouvelle session
    if (!ISSET($_SESSION)){
        session_start();
    }

    $utilisateur = isset($_SESSION['utilisateur']);
    //Header Administrateur
    if(isset($utilisateur) and !empty($_SESSION['utilisateur']) and $_SESSION['utilisateur'] == "admin"){
        require("vue\inclusions\headerAdministrateur.php");
    }
    //Header Utilisateur
    else if(isset($utilisateur) and !empty($_SESSION['utilisateur'])){
        require("vue\inclusions\headerUtilisateur.php");
    }
    //Header Visiteur
    else{
        require("vue\inclusions\headerVisiteur.php");
    }
?>